# Aplicaciones-moviles Nicolas Astudillo
Para abrir el proyecto:
npm i ,
npm install -g @angular/cli ,
ionic s ,


Para instalar android Studio:

npm install @capacitor/android ,
npx cap add android ,
Ionic build Android ,

ionic capacitor sync android ,

Para iniciar android Studio:

npx cap open android ,


opcional:
esto es para el dark mode ,
npm install @capacitor/preferences ,
npx cap sync,


para el pc de la profe:
npm.cmd i -D -E @angular/cli
